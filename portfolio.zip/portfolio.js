

function colorb(element){
	element.style.color = "rgb(255,255,255,0.5)";
}
function colorc(element){
	element.style.color = "white";
}